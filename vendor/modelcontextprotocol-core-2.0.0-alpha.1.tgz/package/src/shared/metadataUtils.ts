import type { BaseMetadata } from '../types/index.js';

/**
 * Utilities for working with {@linkcode BaseMetadata} objects.
 */

/**
 * Gets the display name for an object with {@linkcode BaseMetadata}.
 * For tools, the precedence is: `title` → {@linkcode index.ToolAnnotations | annotations}.`title` → `name`
 * For other objects: `title` → `name`
 * This implements the spec requirement: "if no title is provided, name should be used for display purposes"
 */
export function getDisplayName(metadata: BaseMetadata | (BaseMetadata & { annotations?: { title?: string } })): string {
    // First check for title (not undefined and not empty string)
    if (metadata.title !== undefined && metadata.title !== '') {
        return metadata.title;
    }

    // Then check for annotations.title (only present in Tool objects)
    if ('annotations' in metadata && metadata.annotations?.title) {
        return metadata.annotations.title;
    }

    // Finally fall back to name
    return metadata.name;
}
