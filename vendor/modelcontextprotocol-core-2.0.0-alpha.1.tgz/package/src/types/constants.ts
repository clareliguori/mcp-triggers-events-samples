export const LATEST_PROTOCOL_VERSION = '2025-11-25';
export const DEFAULT_NEGOTIATED_PROTOCOL_VERSION = '2025-03-26';
export const SUPPORTED_PROTOCOL_VERSIONS = [LATEST_PROTOCOL_VERSION, '2025-06-18', '2025-03-26', '2024-11-05', '2024-10-07'];

export const RELATED_TASK_META_KEY = 'io.modelcontextprotocol/related-task';

/**
 * `_meta` key carrying the JSON-RPC `id` of the parent `events/stream` request
 * on every `notifications/events/*` message, so a client with multiple
 * concurrent streams can route notifications to the correct one. See SEP-2575.
 */
export const SUBSCRIPTION_ID_META_KEY = 'io.modelcontextprotocol/subscriptionId';

/* JSON-RPC types */
export const JSONRPC_VERSION = '2.0';

/* Standard JSON-RPC error code constants */
export const PARSE_ERROR = -32_700;
export const INVALID_REQUEST = -32_600;
export const METHOD_NOT_FOUND = -32_601;
export const INVALID_PARAMS = -32_602;
export const INTERNAL_ERROR = -32_603;

/* Events-specific error code constants */
/** MCP-specific error code: Unknown event name. */
export const EVENT_NOT_FOUND = -32_011;
/** MCP-specific error code: User lacks permission for this event/params combination. */
export const EVENT_UNAUTHORIZED = -32_012;
/** MCP-specific error code: Subscription limit reached. */
export const TOO_MANY_SUBSCRIPTIONS = -32_013;
/**
 * Reserved/unused. Gaps are signalled via `truncated: true` in poll/stream/subscribe
 * responses (and a `gap` control envelope on webhook), not as an error.
 * @deprecated Use `truncated` instead. Retained for SDK-internal back-compat reads.
 */
export const CURSOR_EXPIRED = -32_014;
/** MCP-specific error code: Webhook callback URL was rejected by server policy. */
export const INVALID_CALLBACK_URL = -32_015;
/** MCP-specific error code: No subscription matches the supplied key. */
export const SUBSCRIPTION_NOT_FOUND = -32_016;
/** MCP-specific error code: Event type does not support the requested delivery mode. */
export const DELIVERY_MODE_UNSUPPORTED = -32_017;
